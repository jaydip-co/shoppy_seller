

class ShopModel{
  String sellerName;
  String shopName;
  int mobileNo;
  String emailId;
  String shopNo;
  String complexName;
  String landmark;
  String shopType;
  String city;
  int pincode;
  String state;
  String country;
  int accountNo;
  String accountname;
  String ifscCode;
  double latitute;
  double longitute;
  ShopModel({this.sellerName,this.shopName,this.mobileNo,this.emailId,this.shopNo,
  this.complexName,this.landmark,this.city,this.pincode,this.state,this.country,
  this.accountNo,this.accountname,this.ifscCode,this.shopType,this.latitute,this.longitute});

}