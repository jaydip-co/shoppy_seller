import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shoppy_seller/Screen/Home/Home.dart';
import 'package:shoppy_seller/Screen/Home/Widget/HomeDesk.dart';
import 'package:shoppy_seller/Screen/Home/Widget/ProductDesk.dart';

class DrawerChangeNotifier extends ChangeNotifier{
  static String productDesc = "product_desc";
  static String mainDesc = "main_desc";

  Widget _body = ProductDecs();
  Widget _productDescc;

  Widget get getBody => _body;

  void setBody(String s){
    switch(s){
      case "product_desc" : {
        // if(_productDescc == null){
        //   print("null");
        //   _productDescc = ProductDecs();
        // }
        _body = ProductDecs();
        notifyListeners();
        break;
      }
      case "main_desc" : {
        _body = HomeDecs();
        notifyListeners();
        break;
      }
    }
  }

}