
const  String rUserResistration = "/uRegistration";
const String rShopRegistration ="/registration";
const String rAddItem = "/AddItem";
const String rEditItem = "/EditInventory";