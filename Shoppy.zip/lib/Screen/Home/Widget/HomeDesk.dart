import 'package:flutter/material.dart';
class HomeDecs extends StatefulWidget {
  @override
  _HomeDecsState createState() => _HomeDecsState();
}

class _HomeDecsState extends State<HomeDecs> {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("home"),);
  }
}
