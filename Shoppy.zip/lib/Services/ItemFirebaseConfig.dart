
//
const String iProductName = "product_name";
const String iDescription = "description";
const String iProductType = "product_type";
const String iAvailableQuantity = "Available Quantity";
const String iMRP = "MRP";
const String iSellingPrice = "Selling Prince";
const String iUnit = "Unit";
const String iKeywords = "KeyWords";
const String iImages = "Images";
const String iProductCode ="product_code";
const String iRefId ="ref_id";