

const String sAccountNo = "account_number";
const String sAccountName ="account_name";
const String sShopNo = "shop_no";
const String sShopType = "shop_type";
const String sComplexName = "complex_name";
const String sLandmark = "landmark";
const String sCity = "city";
const String sState = "state";
const String sCountry = "county";
const String sPassword = "Confirm_Password";
const String sCurrent_location = "current_location";
const String sEmail_id = "email_id";
const String sGst_Number = "GST_Number";
const String sIFSC_code = "IFSC_Code";
const String sSellerName = "seller_name";
const String sLast_Name = "Last_Name";
const String sMiddle_Name = "Middle_Name";
const String sMobile_Number = "Mobile Number";
const String sShopName = "shop_name";
const String Pan_Number = "pan_number";
const String sPincode = "pincode";
const String sProduct = "products";
const String sSeller_Id = "seller_id";
const String sShop_Name = "shop_name";
const String sAdhar_Number = "adhar_number";
const String sProductCode = "product_codes";
const String sShopGeoPoint = "shop_geo_point";



