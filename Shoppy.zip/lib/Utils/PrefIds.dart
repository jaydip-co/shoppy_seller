
const String SHOP_TYPE = "SHOP_TYPE";